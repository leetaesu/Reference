$(document).ready(function(){
	$(".detail .share").click(function(){
		if($(".detail .shareCon").css("display")=="none"){
			$(".detail .shareCon").show();
		}else{
			$(".detail .shareCon").hide();
		}
	});
	$(".detail .ico_View").click(function(){
		$(".amjun").show();
		$(".detail .photoView").css({"visibility":"visible"});
		$(".detail .photoView").css({"display":"block"});
	});
	$(".amjun,.photoView .close").click(function(){
		$(".amjun").hide();
		$(".detail .photoView").css({"visibility":"hidden"});
		$(".detail .photoView").css({"display":"none"});
	});
	var sizeH = $(document).height();
	$(".amjun").css({"height":sizeH});

});


