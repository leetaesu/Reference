$(document).ready(function(){
	
	var timeSlide;
	var cnt = 0;
	var visual_idx = $('.visual li').length;
	$('.visual').css({'left':'-1400'}).children(':last').prependTo($('.visual'));

	var sildeBanner = {
		next_Slide : function(){
			$('.visual').animate({'left':'-2800px'},1000,'easeInOutExpo',function(){
				$(this).css({'left':'-1400px'}).children(':first').appendTo($(this));
			});
			++cnt;
			if(cnt >= visual_idx){
				cnt  = 0;
			}
			$('.tab li').removeClass('on');
			$('.tab li').eq(cnt).addClass('on');
		},
		prev_Slide : function(){
			$('.visual').animate({'left':'0'},1000,'easeInOutExpo',function(){
				$(this).css({'left':'-1400px'}).children(':last').prependTo($(this));
			});
			--cnt;
			if(cnt < 0){
				cnt = visual_idx -1;
			}
			$('.tab li').removeClass('on');
			$('.tab li').eq(cnt).addClass('on');
		},
		play_Slide : function(){
			clearInterval(timeSlide);
			timeSlide = setInterval(function(){sildeBanner.next_Slide()},2000);
		},
	};
	
	$('.arr_prev').bind('click',function(){
		sildeBanner.prev_Slide();
		sildeBanner.play_Slide();
	});
	$('.arr_next').bind('click',function(){
		sildeBanner.next_Slide();
		sildeBanner.play_Slide();
	});
	$('.main_banner').bind('mouseenter',function(){
		clearInterval(timeSlide);
	});
	$('.main_banner').bind('mouseleave',function(){
		sildeBanner.play_Slide();
	});

	var tab_idx,after_idx;
	$('.tab li').bind('click',function(){
		var before_idx = cnt ;
		tab_idx = $(this).index();
		after_idx= tab_idx - before_idx ;
		if(after_idx < 0){
			after_idx = after_idx * -1;
			if(tab_idx == before_idx ){
				return;
			}else{
				for(var i=0; i<after_idx; i++){
					$('.visual').animate({'left':'0'},0,function(){
						$(this).css({'left':'-1400px'}).children(':last').prependTo($(this));
					});
					--cnt;
					if(cnt < 0){
						cnt = visual_idx -1;
					}
					$('.tab li').removeClass('on');
					$('.tab li').eq(cnt).addClass('on');
				}
			}
			before_idx = tab_idx;
		}else{
			if(tab_idx == before_idx ){
				return;
			}else{
				for(var i=0; i<after_idx; i++){
					$('.visual').animate({'left':'-2800px'},0,function(){
						$(this).css({'left':'-1400px'}).children(':first').appendTo($(this));
					});
					++cnt;
					if(cnt >= visual_idx){
						cnt  = 0;
					}
					$('.tab li').removeClass('on');
					$('.tab li').eq(cnt).addClass('on');
				}
			}
			before_idx = tab_idx;
		}
	});
	sildeBanner.play_Slide();


	// 밑에 배너
	$('.sub_banner ul').css({'left':'-230px'}).find('li:last').prependTo($('.sub_banner ul'));
	$('.sub_banner').bind('mouseenter',function(){
		$('.arrGroup').animate({'opacity':1},1000,function(){});
		clearInterval(timeSlide);
	});
	$('.sub_banner').bind('mouseleave',function(){
		$('.arrGroup').animate({'opacity':0},1000,function(){});
		clearInterval(timeSlide);
	});

	var img_src = $('.sub_banner ul li').eq(2).find('img').attr('src');
	$('.view_img').find('img').attr('src',img_src);
	var timeSlide;
	var galleryBanner = {
		next_Slide : function(){
			var img_src = $('.sub_banner ul li').eq(3).find('img').attr('src');
			$('.sub_banner ul li').css({'opacity':'1.0'});
			$('.sub_banner ul li').eq(3).stop().animate({'opacity':'0'},1000);

			$('.view_img').find('img').attr('src',img_src);
			$('.view_img').transition({'opacity': '0'},0).transition({'opacity': '1'},1500);

			$('.sub_banner>ul').stop().animate({'left':'-460px'},1000,'easeOutBounce',function(){
				$(this).css({'left':'-230px'}).children(':first').appendTo($(this));
			});
		},
		prev_Slide : function(){

			var img_src = $('.sub_banner ul li').eq(1).find('img').attr('src');
			$('.sub_banner ul li').css({'opacity':'1.0'});
			$('.sub_banner ul li').eq(1).stop().animate({'opacity':'0'},1000);

			$('.view_img').find('img').attr('src',img_src);
			$('.view_img').transition({'opacity': '0'},0).transition({'opacity': '1'},1500);

			$('.sub_banner>ul').stop().animate({'left':'0'},1000,'easeOutBounce',function(){
				$(this).css({'left':'-230px'}).children(':last').prependTo($(this));
			});

		},
		play_Slide : function(){
			clearInterval(timeSlide);
			timeSlide = setInterval(function(){galleryBanner.next_Slide()},3000);
		},
	};
	

	$('.arrGroup>a').click(function(){
		switch ($(this).index()){
			case 0 :
				galleryBanner.prev_Slide();
				galleryBanner.play_Slide();
				break;
			case 1 :
				galleryBanner.next_Slide();
				galleryBanner.play_Slide();
				break;
		}
	});
	galleryBanner.play_Slide();


});