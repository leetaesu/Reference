$(document).ready(function(){
	
	var timeSlide;
	var cnt = 0;
	var visual_idx = $('.visual li').length;
	$('.visual').css({'left':'-1400'}).children(':last').prependTo($('.visual'));

	var sildeBanner = {
		next_Slide : function(){
			$('.visual').animate({'left':'-2800px'},200,function(){
				$(this).css({'left':'-1400px'}).children(':first').appendTo($(this));
			});
			++cnt;
			if(cnt >= visual_idx){
				cnt  = 0;
			}
			$('.tab li').removeClass('on');
			$('.tab li').eq(cnt).addClass('on');
		},
		prev_Slide : function(){
			$('.visual').animate({'left':'0'},200,function(){
				$(this).css({'left':'-1400px'}).children(':last').prependTo($(this));
			});
			--cnt;
			if(cnt < 0){
				cnt = visual_idx -1;
			}
			$('.tab li').removeClass('on');
			$('.tab li').eq(cnt).addClass('on');
		},
		play_Slide : function(){
			clearInterval(timeSlide);
			timeSlide = setInterval(function(){sildeBanner.next_Slide()},2000);
		},
	};
	
	$('.arr_prev').bind('click',function(){
		sildeBanner.prev_Slide();
		sildeBanner.play_Slide();
	});
	$('.arr_next').bind('click',function(){
		sildeBanner.next_Slide();
		sildeBanner.play_Slide();
	});
	$('.main_banner').bind('mouseenter',function(){
		clearInterval(timeSlide);
	});
	$('.main_banner').bind('mouseleave',function(){
		sildeBanner.play_Slide();
	});

	var tab_idx,after_idx;
	$('.tab li').bind('click',function(){
		var before_idx = cnt ;
		tab_idx = $(this).index();
		after_idx= tab_idx - before_idx ;
		if(after_idx < 0){
			after_idx = after_idx * -1;
			if(tab_idx == before_idx ){
				return;
			}else{
				for(var i=0; i<after_idx; i++){
					$('.visual').animate({'left':'0'},0,function(){
						$(this).css({'left':'-1400px'}).children(':last').prependTo($(this));
					});
					--cnt;
					if(cnt < 0){
						cnt = visual_idx -1;
					}
					$('.tab li').removeClass('on');
					$('.tab li').eq(cnt).addClass('on');
				}
			}
			before_idx = tab_idx;
		}else{
			if(tab_idx == before_idx ){
				return;
			}else{
				for(var i=0; i<after_idx; i++){
					$('.visual').animate({'left':'-2800px'},0,function(){
						$(this).css({'left':'-1400px'}).children(':first').appendTo($(this));
					});
					++cnt;
					if(cnt >= visual_idx){
						cnt  = 0;
					}
					$('.tab li').removeClass('on');
					$('.tab li').eq(cnt).addClass('on');
				}
			}
			before_idx = tab_idx;
		}
	});
	sildeBanner.play_Slide();



});