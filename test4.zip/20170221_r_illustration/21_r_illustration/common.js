$('.comment_tab').find('li').bind('click',function(){
	$('.comment_con').hide();
	var tab_idx = $(this).index();
	switch(tab_idx){
		case 0 :
			$('.comment_con').eq(tab_idx).show();
			break;
		case 1 :
			$('.comment_con').eq(tab_idx).show();
			break;
	}
});
$(window).scroll(function(event){ 
	var scrollPosY = $(this).scrollTop();
	console.log(scrollPosY);
	if(scrollPosY > 100 && scrollPosY < 2000 ){
		$('.human_2').addClass('on');
	}else{
		$('.human_2').removeClass('on');
	}
	if(scrollPosY > 1000 && scrollPosY < 2900 ){
		$('.flower1').addClass('on');
		$('.flower2').addClass('on');
		$('.human_3').addClass('on');
	}else{
		$('.flower1').removeClass('on');
		$('.flower2').removeClass('on');
		$('.human_3').removeClass('on');
	}
	console.log(scrollPosY);
	if(scrollPosY > 2500){
		$('.human_4').addClass('on');
	}
});